"use client";

import { useState, useTransition } from "react";
import { MonitorSmartphone, Smartphone, Laptop } from "lucide-react";
import { revokeDevice, revokeAllDevices, type TrustedDevice } from "./actions";
import { useT } from "@/lib/i18n/provider";

function friendlyDevice(ua: string | null): string {
  if (!ua) return "Pajisje e panjohur";
  const os = /iPhone/.test(ua) ? "iPhone"
    : /iPad/.test(ua) ? "iPad"
    : /Android/.test(ua) ? "Android"
    : /Mac OS X|Macintosh/.test(ua) ? "macOS"
    : /Windows/.test(ua) ? "Windows"
    : /Linux/.test(ua) ? "Linux"
    : "";
  const browser = /Edg\//.test(ua) ? "Edge"
    : /OPR\//.test(ua) ? "Opera"
    : /Chrome\//.test(ua) ? "Chrome"
    : /Firefox\//.test(ua) ? "Firefox"
    : /Safari\//.test(ua) ? "Safari"
    : "";
  return [browser, os].filter(Boolean).join(" · ") || "Pajisje";
}

function isMobile(ua: string | null): boolean {
  return !!ua && /iPhone|iPad|Android/.test(ua);
}

function fmtDate(s: string): string {
  const d = new Date(s);
  if (isNaN(d.getTime())) return "";
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
}

export function DevicesSection({ devices }: { devices: TrustedDevice[] }) {
  const t = useT();
  const [list, setList] = useState(devices);
  const [pending, start] = useTransition();
  const [busyId, setBusyId] = useState<string | null>(null);

  const onRevoke = (id: string) => {
    setBusyId(id);
    start(async () => {
      const r = await revokeDevice(id);
      if (!r.error) setList((prev) => prev.filter((d) => d.id !== id));
      setBusyId(null);
    });
  };

  return (
    <div className="rounded-2xl border border-border bg-card shadow-sm">
      <div className="flex items-start gap-3 p-5">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-100 text-blue-600">
          <MonitorSmartphone className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-base font-semibold tracking-tight">{t("Trusted devices")}</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {t("Browsers that can sign in without an email code. Remove any you don't recognize.")}
          </p>
        </div>
      </div>

      <div className="border-t border-border/60 p-5">
        {list.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("No trusted devices yet.")}</p>
        ) : (
          <div className="space-y-2">
            {list.map((d) => {
              const Icon = isMobile(d.label) ? Smartphone : Laptop;
              return (
                <div
                  key={d.id}
                  className="flex items-center justify-between gap-3 rounded-xl border border-border/70 bg-card p-3 transition-colors hover:border-border hover:bg-muted/40"
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                      <Icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">
                        {friendlyDevice(d.label)}
                        {d.current && (
                          <span className="ml-2 rounded-full bg-emerald-100 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">
                            {t("This device")}
                          </span>
                        )}
                      </p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {t("Added")} {fmtDate(d.created_at)}
                        {d.expires_at ? ` · ${t("expires")} ${fmtDate(d.expires_at)}` : ""}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRevoke(d.id)}
                    disabled={pending && busyId === d.id}
                    className="shrink-0 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-rose-700 transition hover:bg-rose-50 disabled:opacity-50"
                  >
                    {t("Remove")}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        <form action={revokeAllDevices} className="mt-4">
          <button
            type="submit"
            className="rounded-lg border border-border px-3.5 py-2 text-xs font-semibold text-muted-foreground transition hover:bg-muted"
          >
            {t("Log out of all devices")}
          </button>
        </form>
      </div>
    </div>
  );
}
